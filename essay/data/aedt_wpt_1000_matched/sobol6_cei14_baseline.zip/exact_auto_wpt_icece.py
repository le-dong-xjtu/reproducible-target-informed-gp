from __future__ import annotations

import argparse
import csv
import json
import math
import os
import shutil
import subprocess
import time
import warnings
import zipfile
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import ndtr
from scipy.stats import qmc
from sklearn.exceptions import ConvergenceWarning
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern, WhiteKernel


ROOT = Path(r"C:\Users\leroi\Downloads\aedt_validation")
OUT = ROOT / "exact_auto_wpt_icece_run"
AEDT_SCRIPT = ROOT / "repair_wpt_m1000_series.py"
AEDT = Path(r"C:\Program Files\AnsysEM\AnsysEM20.1\Win64\ansysedt.exe")
REFERENCE = (ROOT / "icece_reference_audit" / "icece_2026_reproducibility" /
             "algorithm_discussion" / "essay" / "scripts" /
             "run_wpt_8d_automated_cei.py")

NAMES = ("ns_t", "nt_t", "s_t_mm", "ri_t_mm",
         "ns_r", "nt_r", "s_r_mm", "ri_r_mm")
INTEGER_COLUMNS = np.array([0, 1, 4, 5])
LOW = np.array([4, 5, 1, 30, 4, 5, 1, 30.], float)
HIGH = np.array([10, 15, 3, 80, 10, 15, 3, 80.], float)
CENTER = (LOW + HIGH) / 2
CENTER[INTEGER_COLUMNS] = np.rint(CENTER[INTEGER_COLUMNS])

TARGET_M = 1000.0
EPSILON = 0.025
LOWER_M = TARGET_M * (1 - EPSILON)
UPPER_M = TARGET_M * (1 + EPSILON)
N_CANDIDATES = 2048
N_CONFIRM_CANDIDATES = 4096
N_CONFIRM = 10
MAX_MODEL_CALLS = 40
MIN_MODEL_CALLS = 2 * len(LOW) + 1
STOP_DELTA = 0.01
STOP_PATIENCE = 3
FEASIBILITY_WEIGHT = 0.75
GP_STARTS = 5
# AEDT 2020.1 can intermittently reject an otherwise valid adaptive mesh.
# A failed launch/solve is not an observation: retry the identical frozen
# geometry until a complete, unit-checked result is exported.
MAX_ATTEMPTS = None

TRAJECTORY_JSON = OUT / "trajectory.json"
TRAJECTORY_CSV = OUT / "trajectory.csv"
STATE_JSON = OUT / "state.json"
CONFIRMATION_PLAN = OUT / "confirmation_plan.json"
FINAL_JSON = OUT / "final_summary.json"
RUN_LOG = OUT / "optimizer.log"


def log(message: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{stamp}] {message}"
    print(line, flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    with RUN_LOG.open("a", encoding="utf-8") as stream:
        stream.write(line + "\n")


def atomic_json(path: Path, value) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8")
    os.replace(str(temp), str(path))


def canonical(points) -> np.ndarray:
    values = np.atleast_2d(np.asarray(points, float)).copy()
    values[:, INTEGER_COLUMNS] = np.rint(values[:, INTEGER_COLUMNS])
    return values


def design_key(point) -> tuple:
    return tuple(float(v) for v in canonical(point)[0])


def normalize(points) -> np.ndarray:
    return (np.asarray(points, float) - LOW) / (HIGH - LOW)


def unit(values) -> np.ndarray:
    values = np.asarray(values, float)
    span = float(np.ptp(values))
    return (values - values.min()) / span if span > 0 else np.zeros_like(values)


def sobol_stream() -> np.ndarray:
    needed = 1 + (MAX_MODEL_CALLS - 1) * N_CANDIDATES + N_CONFIRM_CANDIDATES
    power = int(math.ceil(math.log2(needed)))
    raw = qmc.Sobol(8, scramble=False).random_base2(power)
    return qmc.scale(raw, LOW, HIGH)


def unseen_unique(points, observed) -> np.ndarray:
    seen = {design_key(row) for row in np.asarray(observed, float)}
    answer = []
    local = set()
    for row in canonical(points):
        key = design_key(row)
        if key not in seen and key not in local:
            answer.append(row)
            local.add(key)
    return np.asarray(answer, float)


def deterministic_multistart(starts: int):
    if starts < 1:
        raise ValueError("deterministic starts must be positive")

    def optimizer(objective, initial_theta, bounds):
        candidates = [np.asarray(initial_theta, float)]
        if starts > 1:
            sampler = qmc.Halton(d=len(initial_theta), scramble=False)
            sampler.fast_forward(1)
            candidates.extend(qmc.scale(
                sampler.random(starts - 1), bounds[:, 0], bounds[:, 1]))
        best_theta, best_value = None, np.inf
        for theta in candidates:
            result = minimize(objective, theta, method="L-BFGS-B", jac=True,
                              bounds=bounds)
            if float(result.fun) < best_value:
                best_theta, best_value = result.x, float(result.fun)
        return best_theta, best_value

    return optimizer


def fit_gps(x_raw: np.ndarray, outputs: np.ndarray):
    models = []
    optimize = len(x_raw) >= 4
    for column in range(2):
        if optimize:
            kernel = (ConstantKernel(1., (1e-3, 1e3))
                      * Matern(.35, (.03, 3.), nu=2.5)
                      + WhiteKernel(1e-5, (1e-8, 1e-2)))
            optimizer = deterministic_multistart(GP_STARTS)
        else:
            kernel = (ConstantKernel(1., constant_value_bounds="fixed")
                      * Matern(.35, length_scale_bounds="fixed", nu=2.5)
                      + WhiteKernel(1e-5, noise_level_bounds="fixed"))
            optimizer = None
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ConvergenceWarning)
            warnings.simplefilter("ignore", RuntimeWarning)
            model = GaussianProcessRegressor(
                kernel=kernel, normalize_y=True, alpha=1e-6,
                optimizer=optimizer, n_restarts_optimizer=0,
            ).fit(normalize(x_raw), outputs[:, column])
        models.append(model)
    return models


def gp_snapshot(models) -> dict:
    labels = ("M", "J")
    return {
        label: {
            "kernel": str(model.kernel_),
            "theta_log": [float(value) for value in model.kernel_.theta],
            "log_marginal_likelihood": float(model.log_marginal_likelihood_value_),
        }
        for label, model in zip(labels, models)
    }


def components(models, candidates, observed):
    normalized = normalize(candidates)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        mu_m, sd_m = models[0].predict(normalized, return_std=True)
        mu_j, sd_j = models[1].predict(normalized, return_std=True)
    if not all(np.isfinite(value).all()
               for value in (mu_m, sd_m, mu_j, sd_j)):
        raise FloatingPointError("non-finite deterministic GP prediction")
    sd_m = np.maximum(sd_m, 1e-12)
    sd_j = np.maximum(sd_j, 1e-12)
    pf = ndtr((UPPER_M - mu_m) / sd_m) - ndtr((LOWER_M - mu_m) / sd_m)
    feasible = observed[(observed[:, 0] >= LOWER_M) &
                        (observed[:, 0] <= UPPER_M)]
    if len(feasible):
        incumbent = float(feasible[:, 1].min())
        improvement = incumbent - mu_j
        z = improvement / sd_j
        ei = improvement * ndtr(z) + sd_j * np.exp(-.5*z*z) / math.sqrt(2*math.pi)
        cei = pf * np.maximum(ei, 0) / incumbent
    else:
        incumbent, cei = None, None
    return pf, mu_j, sd_m, cei, incumbent


def read_result(path: Path) -> tuple[float, float, float]:
    with path.open(newline="", encoding="utf-8-sig", errors="strict") as stream:
        rows = list(csv.reader(stream))
    if len(rows) < 2:
        raise ValueError(f"empty AEDT result: {path}")
    values = {}
    for name, raw in zip(rows[0], rows[1]):
        try:
            values[name.strip()] = float(raw.strip())
        except ValueError:
            continue

    def quantity(expression: str, factors: dict[str, float]) -> float:
        for header, value in values.items():
            if expression in header:
                if "[" not in header or not header.endswith("]"):
                    raise ValueError(f"missing unit in result header {header!r}")
                unit_name = header.rsplit("[", 1)[1][:-1]
                if unit_name not in factors:
                    raise ValueError(f"unsupported unit {unit_name!r} in {header!r}")
                answer = value * factors[unit_name]
                if not math.isfinite(answer):
                    raise ValueError(f"non-finite result in {header!r}")
                return answer
        raise KeyError(f"missing AEDT expression {expression!r}")

    inductance = {"pH": 1e-3, "nH": 1., "uH": 1e3,
                  "mH": 1e6, "H": 1e9}
    resistance = {"uOhm": 1e-6, "mOhm": 1e-3,
                  "Ohm": 1., "kOhm": 1e3}
    try:
        mutual = quantity("Matrix1.L(Current1,Current2)", inductance)
    except KeyError:
        mutual = quantity("Matrix1.L(Current2,Current1)", inductance)
    r_tx = quantity("Matrix1.R(Current1,Current1)", resistance)
    r_rx = quantity("Matrix1.R(Current2,Current2)", resistance)
    if mutual <= 0 or r_tx <= 0 or r_rx <= 0:
        raise ValueError(f"non-positive AEDT response M={mutual}, Rtx={r_tx}, Rrx={r_rx}")
    return mutual, r_tx, r_rx


def physical_record(point, call: int, phase: str) -> dict:
    point = canonical(point)[0]
    case = OUT / f"call_{call:03d}"
    case.mkdir(parents=True, exist_ok=True)
    result = case / "result.csv"
    existing = case / "record.json"
    if existing.exists() and result.exists():
        record = json.loads(existing.read_text(encoding="utf-8"))
        if design_key(record["design_vector"]) == design_key(point):
            read_result(result)
            log(f"call {call:03d}: verified cached physical result")
            return record

    settings = {
        "REPAIR_PROJECT": case / "case.aedt",
        "REPAIR_LOG": case / "run.log",
        "REPAIR_RESULT": result,
        "REPAIR_TX_NS": int(point[0]), "REPAIR_TX_NT": int(point[1]),
        "REPAIR_TX_SPACING": point[2], "REPAIR_TX_RADIUS": point[3],
        "REPAIR_RX_NS": int(point[4]), "REPAIR_RX_NT": int(point[5]),
        "REPAIR_RX_SPACING": point[6], "REPAIR_RX_RADIUS": point[7],
        "REPAIR_Z_GAP": 70, "REPAIR_RETURN_HEIGHT": 10,
        "REPAIR_CONTINUOUS": 1, "REPAIR_MESH_LENGTH": 0,
    }
    environment = os.environ.copy()
    environment.update({key: str(value) for key, value in settings.items()})
    started = time.time()
    mesh_fallback = case / "mesh_fallback_1mm.json"
    prior_attempts = []
    for path in case.glob("aedt_attempt_*.log"):
        try:
            prior_attempts.append(int(path.stem.rsplit("_", 1)[1]))
        except ValueError:
            pass
    attempt = max(prior_attempts, default=0) + 1
    recovered = False
    if result.exists():
        for completed_dir in sorted(case.glob("attempt_*"), reverse=True):
            completed_log = completed_dir / "run.log"
            if (completed_log.exists() and
                    "Solve completed" in completed_log.read_text(
                        encoding="utf-8", errors="ignore")):
                mutual, r_tx, r_rx = read_result(result)
                successful_project = completed_dir / "case.aedt"
                completed_text = completed_log.read_text(
                    encoding="utf-8", errors="ignore")
                active_mesh = 1.0 if "Copper mesh maximum length: 1mm" in completed_text else 0.0
                shutil.copy2(completed_log, case / "run.log")
                attempt = int(completed_dir.name.rsplit("_", 1)[1])
                recovered = True
                log(f"call {call:03d}: recovered complete exported result from "
                    f"AEDT attempt {attempt}")
                break
    while not recovered:
        active_mesh = 1.0 if mesh_fallback.exists() else 0.0
        if result.exists():
            result.unlink()
        # Never reuse an incomplete adaptive mesh from a failed AEDT solve.
        # This removes solver-generated cache only; geometry, setup, material,
        # excitation, and optimization state remain identical.
        generated_results = case / "case.aedtresults"
        if generated_results.exists():
            shutil.rmtree(generated_results)
        # A fresh project identity prevents AEDT from deterministically
        # reusing internal mesher state associated with a failed project.
        # All electromagnetic and meshing settings remain unchanged.
        attempt_dir = case / f"attempt_{attempt:03d}"
        attempt_dir.mkdir(parents=True, exist_ok=True)
        attempt_project = attempt_dir / "case.aedt"
        attempt_run_log = attempt_dir / "run.log"
        attempt_results = attempt_dir / "case.aedtresults"
        if attempt_results.exists():
            shutil.rmtree(attempt_results)
        environment["REPAIR_PROJECT"] = str(attempt_project)
        environment["REPAIR_LOG"] = str(attempt_run_log)
        environment["REPAIR_RESULT"] = str(result)
        environment["REPAIR_MESH_LENGTH"] = str(active_mesh)
        aedt_log = case / f"aedt_attempt_{attempt}.log"
        command = (
            f"$p=Start-Process -FilePath '{AEDT}' "
            f"-ArgumentList @('-Logfile','{aedt_log}',"
            f"'-RunScriptAndExit','{AEDT_SCRIPT}') "
            "-WindowStyle Hidden -PassThru; Wait-Process -Id $p.Id; exit $p.ExitCode"
        )
        mesh_label = "automatic" if active_mesh == 0 else "1.0mm fallback"
        log(f"call {call:03d} {phase}: AEDT attempt {attempt} (retry-until-result, "
            f"mesh={mesh_label}) design={point.tolist()}")
        try:
            completed = subprocess.run(
                ["powershell", "-NoProfile", "-Command", command],
                env=environment, timeout=3600, check=False,
            )
            return_code = completed.returncode
        except subprocess.TimeoutExpired:
            return_code = "timeout"
        if result.exists():
            try:
                mutual, r_tx, r_rx = read_result(result)
                successful_project = attempt_project
                if attempt_run_log.exists():
                    shutil.copy2(attempt_run_log, case / "run.log")
                recovered = True
                break
            except (ValueError, KeyError) as error:
                log(f"call {call:03d}: invalid result on attempt {attempt}: {error}")
        else:
            log(f"call {call:03d}: AEDT attempt {attempt} failed, "
                f"exit={return_code}, result_exists={result.exists()}; retrying same design")
        if not recovered and active_mesh == 0:
            atomic_json(mesh_fallback, {
                "reason": "automatic_mesh_attempt_failed",
                "failed_attempt": attempt,
                "fallback_mesh_max_length_mm": 1.0,
            })
            log(f"call {call:03d}: enabling 1.0mm copper mesh fallback")
        attempt += 1

    record = {
        "call": call, "phase": phase,
        "design": dict(zip(NAMES, [int(point[i]) if i in INTEGER_COLUMNS else float(point[i])
                                   for i in range(8)])),
        "design_vector": point.tolist(),
        "return_height_mm": 10.0, "axial_separation_mm": 70.0,
        "frequency_kHz": 85.0, "mesh_max_length_mm": active_mesh,
        "mutual_nH": float(mutual),
        "Rac_tx_ohm": float(r_tx), "Rac_rx_ohm": float(r_rx),
        "J_Rac_sum_ohm": float(r_tx + r_rx),
        "target_error_percent": float(100 * (mutual - TARGET_M) / TARGET_M),
        "feasible": bool(LOWER_M <= mutual <= UPPER_M),
        "posterior_rho": None, "below_threshold_streak": 0,
        "feasible_incumbent_ohm": None, "gp_hyperparameters": None,
        "project": str(successful_project),
        "solver_status": "completed", "attempts": attempt,
        "elapsed_seconds": float(time.time() - started),
    }
    atomic_json(existing, record)
    log(f"call {call:03d}: M={mutual:.6f} nH, Rtx={r_tx:.9g} ohm, "
        f"Rrx={r_rx:.9g} ohm, J={r_tx+r_rx:.9g} ohm, feasible={record['feasible']}")
    return record


def outputs(records) -> tuple[np.ndarray, np.ndarray]:
    x = np.asarray([row["design_vector"] for row in records], float)
    y = np.asarray([[row["mutual_nH"], row["J_Rac_sum_ohm"]]
                    for row in records], float)
    return x, y


def write_trajectory(records) -> None:
    atomic_json(TRAJECTORY_JSON, records)
    fields = ["call", "phase", *NAMES, "return_height_mm",
              "axial_separation_mm", "frequency_kHz", "mesh_max_length_mm", "mutual_nH",
              "Rac_tx_ohm", "Rac_rx_ohm", "J_Rac_sum_ohm",
              "target_error_percent", "feasible", "feasible_incumbent_ohm",
              "posterior_rho", "below_threshold_streak",
              "gp_hyperparameters", "project", "solver_status", "attempts",
              "elapsed_seconds"]
    temp = TRAJECTORY_CSV.with_suffix(".csv.tmp")
    with temp.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for record in records:
            row = {key: record.get(key, "") for key in fields}
            row.update(record["design"])
            row["gp_hyperparameters"] = json.dumps(
                record.get("gp_hyperparameters"), separators=(",", ":"))
            writer.writerow(row)
    os.replace(str(temp), str(TRAJECTORY_CSV))


def state(records, status, **extra) -> None:
    payload = {
        "status": status, "target_M_nH": TARGET_M,
        "feasible_interval_nH": [LOWER_M, UPPER_M],
        "model_building_records": sum(r["phase"] != "confirmation" for r in records),
        "confirmation_records": sum(r["phase"] == "confirmation" for r in records),
        "total_physical_evaluations": len(records),
        "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
        **extra,
    }
    atomic_json(STATE_JSON, payload)


def package() -> Path:
    destination = ROOT / "exact_auto_wpt_icece_run.zip"
    temp = destination.with_suffix(".zip.tmp")
    include = [Path(__file__), AEDT_SCRIPT, REFERENCE, TRAJECTORY_JSON,
               TRAJECTORY_CSV, STATE_JSON, CONFIRMATION_PLAN, FINAL_JSON, RUN_LOG]
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in include:
            if path.exists():
                archive.write(path, path.name)
    os.replace(str(temp), str(destination))
    return destination


def self_test() -> None:
    stream = sobol_stream()
    assert len(stream) >= 1 + 39 * 2048 + 4096
    block = unseen_unique(stream[1:1 + N_CANDIDATES], np.asarray([CENTER]))
    assert len(block) > 0
    assert np.all(block[:, INTEGER_COLUMNS] == np.rint(block[:, INTEGER_COLUMNS]))
    assert np.all((normalize(block) >= 0) & (normalize(block) <= 1))
    optimizer = deterministic_multistart(5)
    assert callable(optimizer)
    print("self-test passed: stream, canonicalization, normalization, deterministic optimizer",
          flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Exact ICECE automatic cEI with AEDT oracle")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if args.self_test:
        self_test()
        return
    if not AEDT.exists() or not AEDT_SCRIPT.exists() or not REFERENCE.exists():
        raise FileNotFoundError("AEDT, AEDT construction script, or ICECE reference is missing")

    stream = sobol_stream()
    records = (json.loads(TRAJECTORY_JSON.read_text(encoding="utf-8"))
               if TRAJECTORY_JSON.exists() else [])
    if not records:
        state([], "evaluating_center")
        records.append(physical_record(CENTER, 1, "center"))
        write_trajectory(records)
        package()

    model_records = [row for row in records if row["phase"] != "confirmation"]
    if len(model_records) != len(records) and not CONFIRMATION_PLAN.exists():
        raise RuntimeError("confirmation records exist without a frozen confirmation plan")

    stopped_naturally = False
    stop_reason = None
    streak = 0
    first_feasible = next((r["call"] for r in model_records if r["feasible"]), None)

    # Recompute every posterior decision from the immutable physical ledger.
    # This restores the exact streak after interruption rather than resetting it.
    for n in range(1, len(model_records) + 1):
        prefix = model_records[:n]
        x_prefix, y_prefix = outputs(prefix)
        models = fit_gps(x_prefix, y_prefix)
        prefix[-1]["gp_hyperparameters"] = gp_snapshot(models)
        feasible_values = y_prefix[(y_prefix[:, 0] >= LOWER_M) &
                                   (y_prefix[:, 0] <= UPPER_M), 1]
        prefix[-1]["feasible_incumbent_ohm"] = (
            float(feasible_values.min()) if len(feasible_values) else None)
        if first_feasible is not None and n >= first_feasible:
            step = n - 1
            raw = stream[1 + step*N_CANDIDATES:1 + (step+1)*N_CANDIDATES]
            candidates = unseen_unique(raw, x_prefix)
            _, _, _, cei, _ = components(models, candidates, y_prefix)
            rho = float(np.max(cei))
            streak = streak + 1 if rho <= STOP_DELTA else 0
            prefix[-1]["posterior_rho"] = rho
            prefix[-1]["below_threshold_streak"] = streak
        write_trajectory(records)

    while len(model_records) < MAX_MODEL_CALLS and not CONFIRMATION_PLAN.exists():
        x_raw, y = outputs(model_records)
        models = fit_gps(x_raw, y)
        step = len(model_records) - 1
        raw = stream[1 + step*N_CANDIDATES:1 + (step+1)*N_CANDIDATES]
        candidates = unseen_unique(raw, x_raw)
        pf, _, sd_m, cei, incumbent = components(models, candidates, y)
        has_feasible = incumbent is not None
        if has_feasible:
            rho = float(np.max(cei))
            # On a fresh continuation the current-prefix rho was already restored above.
            if model_records[-1].get("posterior_rho") is None:
                streak = streak + 1 if rho <= STOP_DELTA else 0
                model_records[-1]["posterior_rho"] = rho
                model_records[-1]["below_threshold_streak"] = streak
            else:
                rho = float(model_records[-1]["posterior_rho"])
                streak = int(model_records[-1]["below_threshold_streak"])
            score = cei
            phase = "cei"
        else:
            rho = None
            score = FEASIBILITY_WEIGHT*unit(pf) + (1-FEASIBILITY_WEIGHT)*unit(sd_m)
            phase = "feasibility"
        model_records[-1]["gp_hyperparameters"] = gp_snapshot(models)
        model_records[-1]["feasible_incumbent_ohm"] = incumbent
        write_trajectory(records)
        state(records, "model_building_refit", current_model_count=len(model_records),
              rho=rho, below_threshold_streak=streak)

        if has_feasible and len(model_records) >= MIN_MODEL_CALLS and streak >= STOP_PATIENCE:
            stopped_naturally = True
            stop_reason = "three_consecutive_relative_cEI_values_at_or_below_0.01"
            break

        chosen = candidates[int(np.argmax(score))]
        next_call = len(records) + 1
        state(records, "evaluating_model_candidate", next_call=next_call,
              phase=phase, candidate=chosen.tolist(), rho=rho,
              below_threshold_streak=streak)
        record = physical_record(chosen, next_call, phase)
        records.append(record)
        model_records.append(record)
        if first_feasible is None and record["feasible"]:
            first_feasible = len(model_records)
        write_trajectory(records)
        package()

    if not CONFIRMATION_PLAN.exists():
        if not any(row["feasible"] for row in model_records):
            state(records, "failed_no_feasible_design", current_model_count=len(model_records))
            package()
            raise RuntimeError("no feasible observation within 40 model-building evaluations")
        if stop_reason is None:
            stop_reason = "maximum_40_model_building_evaluations"
        x_raw, y = outputs(model_records)
        models = fit_gps(x_raw, y)
        confirmation_start = 1 + (MAX_MODEL_CALLS - 1) * N_CANDIDATES
        raw = stream[confirmation_start:confirmation_start + N_CONFIRM_CANDIDATES]
        candidates = unseen_unique(raw, x_raw)
        pf, mu_j, _, _, _ = components(models, candidates, y)
        scores = pf * np.exp(-unit(mu_j))
        order = np.argsort(-scores, kind="stable")[:N_CONFIRM]
        plan = {
            "frozen_after_model_building": len(model_records),
            "stopped_naturally": stopped_naturally,
            "stop_reason": stop_reason,
            "final_rho": model_records[-1].get("posterior_rho"),
            "final_below_threshold_streak": model_records[-1].get("below_threshold_streak"),
            "gp_hyperparameters": gp_snapshot(models),
            "pool_stream_start": confirmation_start,
            "pool_size": N_CONFIRM_CANDIDATES,
            "ranking": "pF*exp(-unit(mu_J))",
            "no_refit_between_confirmations": True,
            "designs": [candidates[i].tolist() for i in order],
            "scores": [float(scores[i]) for i in order],
        }
        atomic_json(CONFIRMATION_PLAN, plan)
        state(records, "confirmation_plan_frozen", **{
            "model_building_count": len(model_records), "stop_reason": stop_reason})
        package()

    plan = json.loads(CONFIRMATION_PLAN.read_text(encoding="utf-8"))
    completed_confirmation = sum(row["phase"] == "confirmation" for row in records)
    for index, point in enumerate(plan["designs"][completed_confirmation:],
                                  start=completed_confirmation + 1):
        next_call = len(records) + 1
        state(records, "evaluating_confirmation", confirmation_index=index,
              next_call=next_call, candidate=point,
              frozen_model_building_count=plan["frozen_after_model_building"])
        records.append(physical_record(point, next_call, "confirmation"))
        write_trajectory(records)
        package()

    feasible = [row for row in records if row["feasible"]]
    best = min(feasible, key=lambda row: row["J_Rac_sum_ohm"])
    summary = {
        "status": "complete", "qualified": True,
        "target_M_nH": TARGET_M, "feasible_interval_nH": [LOWER_M, UPPER_M],
        "objective": "Rac_tx_ohm + Rac_rx_ohm",
        "first_feasible_model_call": first_feasible,
        "n_model_building": plan["frozen_after_model_building"],
        "n_confirmation": N_CONFIRM, "total_evaluations": len(records),
        "stopped_naturally": plan["stopped_naturally"],
        "stop_reason": plan["stop_reason"],
        "final_rho": plan["final_rho"],
        "final_below_threshold_streak": plan["final_below_threshold_streak"],
        "best_observation": best,
    }
    atomic_json(FINAL_JSON, summary)
    state(records, "complete", best_call=best["call"],
          best_M_nH=best["mutual_nH"], best_J_ohm=best["J_Rac_sum_ohm"])
    archive = package()
    log(f"complete: best call {best['call']}, M={best['mutual_nH']:.6f} nH, "
        f"J={best['J_Rac_sum_ohm']:.9g} ohm; package={archive}")


if __name__ == "__main__":
    main()
