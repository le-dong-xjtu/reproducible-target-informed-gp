from __future__ import annotations

import csv
import json
import os
import shutil
import time
import zipfile
from pathlib import Path

import numpy as np

import exact_auto_wpt_icece as core


ROOT = core.ROOT
OUT = ROOT / "baseline_sobol6_cei14_run"
N_INITIAL = 6
N_SEQUENTIAL = 14
N_MODEL = N_INITIAL + N_SEQUENTIAL
N_CONFIRM = 10

TRAJECTORY_JSON = OUT / "trajectory.json"
TRAJECTORY_CSV = OUT / "trajectory.csv"
STATE_JSON = OUT / "state.json"
CONFIRMATION_PLAN = OUT / "confirmation_plan.json"
FINAL_JSON = OUT / "final_summary.json"
COMPARISON_JSON = OUT / "comparison_vs_automatic.json"
RUN_LOG = OUT / "optimizer.log"


def configure_core_paths() -> None:
    core.OUT = OUT
    core.TRAJECTORY_JSON = TRAJECTORY_JSON
    core.TRAJECTORY_CSV = TRAJECTORY_CSV
    core.STATE_JSON = STATE_JSON
    core.CONFIRMATION_PLAN = CONFIRMATION_PLAN
    core.FINAL_JSON = FINAL_JSON
    core.RUN_LOG = RUN_LOG


def atomic_json(path: Path, value) -> None:
    core.atomic_json(path, value)


def log(message: str) -> None:
    core.log(message)


def state(records, status, **extra) -> None:
    payload = {
        "status": status,
        "method": "6 fixed Sobol initial + 14 sequential conventional cEI + 10 frozen confirmations",
        "target_M_nH": core.TARGET_M,
        "feasible_interval_nH": [core.LOWER_M, core.UPPER_M],
        "model_records": sum(row["phase"] != "confirmation" for row in records),
        "confirmation_records": sum(row["phase"] == "confirmation" for row in records),
        "total_evaluations": len(records),
        "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
        **extra,
    }
    atomic_json(STATE_JSON, payload)


def package() -> Path:
    destination = ROOT / "baseline_sobol6_cei14_run.zip"
    temporary = destination.with_suffix(".zip.tmp")
    include = [Path(__file__), Path(core.__file__), core.AEDT_SCRIPT,
               core.REFERENCE, TRAJECTORY_JSON, TRAJECTORY_CSV, STATE_JSON,
               CONFIRMATION_PLAN, FINAL_JSON, COMPARISON_JSON, RUN_LOG]
    with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in include:
            if path.exists():
                archive.write(path, path.name)
    os.replace(str(temporary), str(destination))
    return destination


def initial_designs(stream) -> np.ndarray:
    # Exact conventional baseline in run_wpt_8d_multitarget_validation.py:
    # unseen_unique(stream[1:1+16], empty)[:6].
    return core.unseen_unique(stream[1:17], np.empty((0, 8)))[:N_INITIAL]


def model_arrays(records):
    model = [row for row in records if row["phase"] != "confirmation"]
    x, y = core.outputs(model)
    return model, x, y


def refresh_latest_posterior(records, candidates, models, y) -> tuple:
    pf, _, sd_m, cei, incumbent = core.components(models, candidates, y)
    latest = [row for row in records if row["phase"] != "confirmation"][-1]
    latest["gp_hyperparameters"] = core.gp_snapshot(models)
    latest["feasible_incumbent_ohm"] = incumbent
    latest["posterior_rho"] = None if cei is None else float(np.max(cei))
    latest["below_threshold_streak"] = 0
    core.write_trajectory(records)
    return pf, sd_m, cei, incumbent


def write_comparison(summary: dict) -> None:
    automatic_path = ROOT / "exact_auto_wpt_icece_run" / "final_summary.json"
    automatic = json.loads(automatic_path.read_text(encoding="utf-8"))
    auto_best = automatic["best_observation"]
    base_best = summary["best_observation"]
    delta = base_best["J_Rac_sum_ohm"] - auto_best["J_Rac_sum_ohm"]
    comparison = {
        "same_total_budget": summary["total_evaluations"] == automatic["total_evaluations"],
        "target_M_nH": core.TARGET_M,
        "automatic_center_start": {
            "allocation": {
                "model_building": automatic["n_model_building"],
                "confirmation": automatic["n_confirmation"],
            },
            "best_call": auto_best["call"],
            "best_M_nH": auto_best["mutual_nH"],
            "best_J_ohm": auto_best["J_Rac_sum_ohm"],
            "design": auto_best["design_vector"],
        },
        "conventional_sobol6_cei14": {
            "allocation": {"initial": N_INITIAL, "sequential": N_SEQUENTIAL,
                           "confirmation": N_CONFIRM},
            "best_call": base_best["call"],
            "best_M_nH": base_best["mutual_nH"],
            "best_J_ohm": base_best["J_Rac_sum_ohm"],
            "design": base_best["design_vector"],
        },
        "baseline_minus_automatic_J_ohm": delta,
        "baseline_relative_J_difference_percent": (
            100 * delta / auto_best["J_Rac_sum_ohm"]),
        "lower_J_winner": ("conventional_sobol6_cei14" if delta < 0 else
                           "automatic_center_start" if delta > 0 else "tie"),
        "comparison_scope": "one deterministic 1000-nH AEDT trajectory per method",
    }
    atomic_json(COMPARISON_JSON, comparison)


def main() -> None:
    configure_core_paths()
    OUT.mkdir(parents=True, exist_ok=True)
    stream = core.sobol_stream()
    fixed_initial = initial_designs(stream)
    if len(fixed_initial) != N_INITIAL:
        raise RuntimeError("failed to construct six unique Sobol initial designs")

    records = (json.loads(TRAJECTORY_JSON.read_text(encoding="utf-8"))
               if TRAJECTORY_JSON.exists() else [])
    if records and any(row["phase"] == "confirmation" for row in records) and not CONFIRMATION_PLAN.exists():
        raise RuntimeError("confirmation records exist without frozen plan")

    completed_model = sum(row["phase"] != "confirmation" for row in records)
    for index in range(completed_model, N_INITIAL):
        call = len(records) + 1
        state(records, "evaluating_initial_sobol", initial_index=index + 1,
              next_call=call, candidate=fixed_initial[index].tolist())
        records.append(core.physical_record(
            fixed_initial[index], call, "initial_sobol"))
        core.write_trajectory(records)
        package()

    while (sum(row["phase"] != "confirmation" for row in records) < N_MODEL
           and not CONFIRMATION_PLAN.exists()):
        model, x_raw, y = model_arrays(records)
        step = len(x_raw) - 1
        raw = stream[1 + step*core.N_CANDIDATES:
                     1 + (step+1)*core.N_CANDIDATES]
        candidates = core.unseen_unique(raw, x_raw)
        models = core.fit_gps(x_raw, y)
        pf, _, cei, incumbent = refresh_latest_posterior(
            records, candidates, models, y)
        if incumbent is None:
            score = pf
            phase = "sequential_pf"
        else:
            score = cei
            phase = "sequential_cei"
        chosen_index = int(np.argmax(score))
        chosen = candidates[chosen_index]
        call = len(records) + 1
        state(records, "evaluating_sequential", next_call=call, phase=phase,
              sequential_index=len(x_raw)-N_INITIAL+1,
              candidate=chosen.tolist(), acquisition=float(score[chosen_index]))
        records.append(core.physical_record(chosen, call, phase))
        core.write_trajectory(records)
        package()

    if not CONFIRMATION_PLAN.exists():
        model, x_raw, y = model_arrays(records)
        models = core.fit_gps(x_raw, y)
        begin = 1 + (core.MAX_MODEL_CALLS - 1) * core.N_CANDIDATES
        raw = stream[begin:begin + core.N_CONFIRM_CANDIDATES]
        candidates = core.unseen_unique(raw, x_raw)
        pf, mu_j, _, _, _ = core.components(models, candidates, y)
        score = pf * np.exp(-core.unit(mu_j))
        order = np.argsort(-score, kind="stable")[:N_CONFIRM]
        plan = {
            "frozen_after_model_observations": N_MODEL,
            "pool_stream_start": begin,
            "pool_size": core.N_CONFIRM_CANDIDATES,
            "ranking": "pF*exp(-unit(mu_J))",
            "no_refit_between_confirmations": True,
            "gp_hyperparameters": core.gp_snapshot(models),
            "designs": [candidates[index].tolist() for index in order],
            "scores": [float(score[index]) for index in order],
        }
        atomic_json(CONFIRMATION_PLAN, plan)
        state(records, "confirmation_plan_frozen")
        package()

    plan = json.loads(CONFIRMATION_PLAN.read_text(encoding="utf-8"))
    completed_confirmation = sum(row["phase"] == "confirmation" for row in records)
    for index, point in enumerate(plan["designs"][completed_confirmation:],
                                  start=completed_confirmation + 1):
        call = len(records) + 1
        state(records, "evaluating_confirmation", confirmation_index=index,
              next_call=call, candidate=point)
        records.append(core.physical_record(point, call, "confirmation"))
        core.write_trajectory(records)
        package()

    feasible = [row for row in records if row["feasible"]]
    summary = {
        "status": "complete",
        "method": "6 fixed Sobol initial + 14 sequential conventional cEI + 10 frozen confirmations",
        "qualified": bool(feasible),
        "target_M_nH": core.TARGET_M,
        "feasible_interval_nH": [core.LOWER_M, core.UPPER_M],
        "objective": "Rac_tx_ohm + Rac_rx_ohm",
        "n_initial": N_INITIAL,
        "n_sequential": N_SEQUENTIAL,
        "n_model": N_MODEL,
        "n_confirmation": N_CONFIRM,
        "total_evaluations": len(records),
        "best_observation": (min(feasible, key=lambda row: row["J_Rac_sum_ohm"])
                             if feasible else min(
                                 records, key=lambda row: abs(row["mutual_nH"]-core.TARGET_M))),
    }
    atomic_json(FINAL_JSON, summary)
    write_comparison(summary)
    state(records, "complete", best_call=summary["best_observation"]["call"],
          best_M_nH=summary["best_observation"]["mutual_nH"],
          best_J_ohm=summary["best_observation"]["J_Rac_sum_ohm"])
    archive = package()
    best = summary["best_observation"]
    log(f"complete: best call {best['call']}, M={best['mutual_nH']:.6f} nH, "
        f"J={best['J_Rac_sum_ohm']:.9g} ohm; package={archive}")


if __name__ == "__main__":
    main()
