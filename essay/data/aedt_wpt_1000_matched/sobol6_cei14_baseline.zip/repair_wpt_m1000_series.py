import math
import os
import traceback


PROJECT_PATH = os.environ.get(
    "REPAIR_PROJECT",
    r"C:\Users\leroi\Downloads\aedt_validation\wpt_m1000_verify.aedt")
LOG_PATH = os.environ.get(
    "REPAIR_LOG",
    r"C:\Users\leroi\Downloads\aedt_validation\repair_wpt_m1000_series.log")
RESULT_PATH = os.environ.get(
    "REPAIR_RESULT",
    r"C:\Users\leroi\Downloads\aedt_validation\M1000_verify_results.csv")

WIRE_D = 0.68
RETURN_HEIGHT = float(os.environ.get("REPAIR_RETURN_HEIGHT", "4.0"))
TX_NS = int(os.environ.get("REPAIR_TX_NS", "7"))
TX_NT = int(os.environ.get("REPAIR_TX_NT", "6"))
TX_SPACING = float(os.environ.get("REPAIR_TX_SPACING", "2.088470458984375"))
TX_RADIUS = float(os.environ.get("REPAIR_TX_RADIUS", "59.796600341796875"))
RX_NS = int(os.environ.get("REPAIR_RX_NS", "7"))
RX_NT = int(os.environ.get("REPAIR_RX_NT", "7"))
RX_SPACING = float(os.environ.get("REPAIR_RX_SPACING", "1.389434814453125"))
RX_RADIUS = float(os.environ.get("REPAIR_RX_RADIUS", "56.418304443359375"))
Z_GAP = float(os.environ.get("REPAIR_Z_GAP", "70.0"))
CONTINUOUS_MODE = os.environ.get("REPAIR_CONTINUOUS", "0") == "1"
MESH_LENGTH = float(os.environ.get("REPAIR_MESH_LENGTH", "0"))
LEAD_LENGTH = 2.0
GAP_ARC_HALF = 0.60


log_file = open(LOG_PATH, "w")


def log(message):
    log_file.write(str(message) + "\n")
    log_file.flush()


def mm(value):
    return "%.12gmm" % float(value)


def make_series_centerline(ns, nt, spacing, inner_radius, z_value):
    """Build constant-radius turns joined in series at a visible +X gap."""
    pitch = WIRE_D + spacing
    points = []
    transitions = []

    for turn in range(nt):
        radius = inner_radius + turn * pitch
        half_gap_angle = GAP_ARC_HALF / radius
        theta_start = half_gap_angle
        theta_end = 2.0 * math.pi - half_gap_angle

        turn_points = []
        for index in range(ns + 1):
            theta = theta_start + (theta_end - theta_start) * index / ns
            turn_points.append((radius * math.cos(theta),
                                radius * math.sin(theta), z_value))

        if points:
            # The segment from the previous endpoint to this first point is the
            # physical series jumper between adjacent turns.
            transitions.append((len(points) - 1, len(points)))
        points.extend(turn_points)

    return points, transitions


def create_series_coil(editor, name, ns, nt, spacing, inner_radius,
                       z_value, color):
    if CONTINUOUS_MODE:
        pitch = spacing + WIRE_D
        start_radius = inner_radius - 0.5 * pitch
        points_data = []
        for index in range(ns * nt + 1):
            angle = 2.0 * math.pi * index / ns
            radius = start_radius + pitch * index / ns
            points_data.append((radius * math.cos(angle),
                                radius * math.sin(angle), z_value))
        transitions = []
    else:
        points_data, transitions = make_series_centerline(
            ns, nt, spacing, inner_radius, z_value)

    points = ["NAME:PolylinePoints"]
    for x_pos, y_pos, z_pos in points_data:
        points.append(["NAME:PLPoint", "X:=", mm(x_pos),
                       "Y:=", mm(y_pos), "Z:=", mm(z_pos)])

    segments = ["NAME:PolylineSegments"]
    for index in range(len(points_data) - 1):
        segments.append(["NAME:PLSegment", "SegmentType:=", "Line",
                         "StartIndex:=", index, "NoOfPoints:=", 2])

    xsection = ["NAME:PolylineXSection", "XSectionType:=", "Circle",
                "XSectionOrient:=", "Auto", "XSectionWidth:=", mm(WIRE_D),
                "XSectionTopWidth:=", "0mm", "XSectionHeight:=", "0mm",
                "XSectionNumSegments:=", "6",
                "XSectionBendType:=", "Round"]

    editor.CreatePolyline(
        ["NAME:PolylineParameters", "IsPolylineCovered:=", False,
         "IsPolylineClosed:=", False, points, segments, xsection],
        ["NAME:Attributes", "Name:=", name, "Flags:=", "", "Color:=", color,
         "Transparency:=", 0, "PartCoordinateSystem:=", "Global",
         "MaterialValue:=", '"copper"', "SolveInside:=", True]
    )
    return points_data, transitions


def close_coil_and_add_terminal(editor, prefix, coil_name, points,
                                z_value, color):
    first_point = points[0]
    last_point = points[-1]
    lead_start = (first_point[0] - LEAD_LENGTH, first_point[1], z_value)

    lead_name = prefix + "_Lead"
    editor.CreateCylinder(
        ["NAME:CylinderParameters",
         "XCenter:=", mm(lead_start[0]), "YCenter:=", mm(lead_start[1]),
         "ZCenter:=", mm(z_value), "Radius:=", mm(WIRE_D / 2.0),
         "Height:=", mm(LEAD_LENGTH), "WhichAxis:=", "X", "NumSides:=", "12"],
        ["NAME:Attributes", "Name:=", lead_name, "Flags:=", "", "Color:=", color,
         "Transparency:=", 0, "PartCoordinateSystem:=", "Global",
         "MaterialValue:=", '"copper"', "SolveInside:=", True]
    )

    # Use an explicit elevated return instead of AEDT's JEDEC bondwire.  In
    # AEDT 2020.1 the JEDEC path can sag through the intermediate turns and
    # silently short them.  Vertical risers keep the only z=coil-plane contact
    # points at the intended outer endpoint and inner lead endpoint.
    return_name = prefix + "_Return"
    return_points_data = [
        last_point,
        (last_point[0], last_point[1], z_value + RETURN_HEIGHT),
        (lead_start[0], lead_start[1], z_value + RETURN_HEIGHT),
        lead_start,
    ]
    return_points = ["NAME:PolylinePoints"]
    for x_pos, y_pos, z_pos in return_points_data:
        return_points.append(["NAME:PLPoint", "X:=", mm(x_pos),
                              "Y:=", mm(y_pos), "Z:=", mm(z_pos)])
    return_segments = ["NAME:PolylineSegments"]
    for index in range(3):
        return_segments.append(["NAME:PLSegment", "SegmentType:=", "Line",
                                "StartIndex:=", index, "NoOfPoints:=", 2])
    return_xsection = [
        "NAME:PolylineXSection", "XSectionType:=", "Circle",
        "XSectionOrient:=", "Auto", "XSectionWidth:=", mm(WIRE_D),
        "XSectionTopWidth:=", "0mm", "XSectionHeight:=", "0mm",
        "XSectionNumSegments:=", "6", "XSectionBendType:=", "Round"
    ]
    editor.CreatePolyline(
        ["NAME:PolylineParameters", "IsPolylineCovered:=", False,
         "IsPolylineClosed:=", False, return_points, return_segments,
         return_xsection],
        ["NAME:Attributes", "Name:=", return_name, "Flags:=", "",
         "Color:=", color, "Transparency:=", 0,
         "PartCoordinateSystem:=", "Global", "MaterialValue:=", '"copper"',
         "SolveInside:=", True]
    )

    editor.Unite(
        ["NAME:Selections", "Selections:=",
         "%s,%s,%s" % (coil_name, lead_name, return_name)],
        ["NAME:UniteParameters", "KeepOriginals:=", False]
    )

    terminal_name = prefix + "_Terminal"
    terminal_x = lead_start[0] + LEAD_LENGTH / 2.0
    editor.CreateCircle(
        ["NAME:CircleParameters", "IsCovered:=", True,
         "XCenter:=", mm(terminal_x), "YCenter:=", mm(lead_start[1]),
         "ZCenter:=", mm(z_value), "Radius:=", mm(WIRE_D / 2.0),
         "WhichAxis:=", "X", "NumSegments:=", "12"],
        ["NAME:Attributes", "Name:=", terminal_name, "Flags:=", "",
         "Color:=", "(0 255 0)", "Transparency:=", 0,
         "PartCoordinateSystem:=", "Global", "MaterialValue:=", '"copper"',
         "SolveInside:=", True]
    )
    return terminal_name


try:
    log("Rebuilding M1000 with explicit series-connected turns")
    if os.path.exists(PROJECT_PATH):
        os.remove(PROJECT_PATH)

    project = oDesktop.NewProject()
    project.SaveAs(PROJECT_PATH, True)
    project.InsertDesign("Maxwell 3D", "M1000", "EddyCurrent", "")
    design = project.SetActiveDesign("M1000")
    editor = design.SetActiveEditor("3D Modeler")
    editor.SetModelUnits(["NAME:Units Parameter", "Units:=", "mm", "Rescale:=", False])

    tx_points, tx_links = create_series_coil(
        editor, "TX_Spiral", TX_NS, TX_NT, TX_SPACING,
        TX_RADIUS, 0.0, "(255 128 0)")
    rx_points, rx_links = create_series_coil(
        editor, "RX_Spiral", RX_NS, RX_NT, RX_SPACING,
        RX_RADIUS, Z_GAP, "(0 180 130)")
    log("TX series transitions: %d (expected 5)" % len(tx_links))
    log("RX series transitions: %d (expected 6)" % len(rx_links))

    tx_terminal = close_coil_and_add_terminal(
        editor, "TX", "TX_Spiral", tx_points, 0.0, "(255 128 0)")
    rx_terminal = close_coil_and_add_terminal(
        editor, "RX", "RX_Spiral", rx_points, Z_GAP, "(0 180 130)")

    editor.CreateRegion(
        ["NAME:RegionParameters", "+XPaddingType:=", "Percentage Offset", "+XPadding:=", "50",
         "-XPaddingType:=", "Percentage Offset", "-XPadding:=", "50",
         "+YPaddingType:=", "Percentage Offset", "+YPadding:=", "50",
         "-YPaddingType:=", "Percentage Offset", "-YPadding:=", "50",
         "+ZPaddingType:=", "Percentage Offset", "+ZPadding:=", "50",
         "-ZPaddingType:=", "Percentage Offset", "-ZPadding:=", "50"],
        ["NAME:Attributes", "Name:=", "Region", "Flags:=", "Wireframe#",
         "Color:=", "(143 175 143)", "Transparency:=", 0.86,
         "PartCoordinateSystem:=", "Global", "MaterialValue:=", '"vacuum"',
         "SolveInside:=", True]
    )

    boundary = design.GetModule("BoundarySetup")
    boundary.AssignCurrent(
        ["NAME:Current1", "Objects:=", [tx_terminal], "Phase:=", "0deg",
         "Current:=", "1A", "IsSolid:=", True, "Point out of terminal:=", False])
    boundary.AssignCurrent(
        ["NAME:Current2", "Objects:=", [rx_terminal], "Phase:=", "0deg",
         "Current:=", "0mA", "IsSolid:=", True, "Point out of terminal:=", False])
    boundary.SetEddyEffect(
        ["NAME:Eddy Effect Setting", ["NAME:EddyEffectVector",
         ["NAME:Data", "Object Name:=", "TX_Spiral", "Eddy Effect:=", True,
          "Displacement Current:=", False],
         ["NAME:Data", "Object Name:=", "RX_Spiral", "Eddy Effect:=", True,
          "Displacement Current:=", False],
         ["NAME:Data", "Object Name:=", "Region", "Eddy Effect:=", False,
          "Displacement Current:=", False]]]
    )

    if MESH_LENGTH > 0:
        mesh = design.GetModule("MeshSetup")
        mesh.AssignLengthOp(
            ["NAME:CopperLength", "RefineInside:=", True,
             "Objects:=", ["TX_Spiral", "RX_Spiral"],
             "RestrictElem:=", False, "NumMaxElem:=", "1000",
             "RestrictLength:=", True, "MaxLength:=", mm(MESH_LENGTH)]
        )
        log("Copper mesh maximum length: %s" % mm(MESH_LENGTH))

    analysis = design.GetModule("AnalysisSetup")
    analysis.InsertSetup(
        "EddyCurrent",
        ["NAME:Setup1", "Enabled:=", True,
         "MaximumPasses:=", 4, "MinimumPasses:=", 2,
         "MinimumConvergedPasses:=", 1, "PercentRefinement:=", 30,
         "SolveFieldOnly:=", False, "PercentError:=", 2.0,
         "SolveMatrixAtLast:=", True, "UseIterativeSolver:=", False,
         "RelativeResidual:=", 1E-05, "Frequency:=", "85kHz",
         "HasSweepSetup:=", False, "UseHighOrderShapeFunc:=", False,
         "UseMuLink:=", False]
    )

    matrix = design.GetModule("MaxwellParameterSetup")
    matrix.AssignMatrix(
        ["NAME:Matrix1", ["NAME:MatrixEntry",
         ["NAME:MatrixEntry", "Source:=", "Current1"],
         ["NAME:MatrixEntry", "Source:=", "Current2"]]]
    )

    project.Save()
    validation = design.ValidateDesign()
    log("ValidateDesign: %d" % validation)
    if validation != 1:
        raise RuntimeError("AEDT design validation failed")

    log("Solving repaired design")
    design.AnalyzeAll()
    log("Solve completed")

    report = design.GetModule("ReportSetup")
    report.CreateReport(
        "MutualInductance", "EddyCurrent", "Data Table",
        "Setup1 : LastAdaptive", [], ["Freq:=", ["All"]],
        ["X Component:=", "Freq", "Y Component:=",
         ["Matrix1.L(Current1,Current1)", "Matrix1.L(Current1,Current2)",
          "Matrix1.L(Current2,Current1)", "Matrix1.L(Current2,Current2)",
          "Matrix1.R(Current1,Current1)", "Matrix1.R(Current2,Current2)"]]
    )
    if os.path.exists(RESULT_PATH):
        os.remove(RESULT_PATH)
    report.ExportToFile("MutualInductance", RESULT_PATH, False)
    result_file = open(RESULT_PATH, "r")
    log("Results:\n" + result_file.read())
    result_file.close()
    project.Save()

except Exception:
    log("ERROR:\n" + traceback.format_exc())
    for severity in [2, 1, 0]:
        try:
            log("AEDT messages severity %d: %s" %
                (severity, str(oDesktop.GetMessages("", "", severity))))
        except Exception:
            pass
    raise

finally:
    try:
        project.Save()
        oDesktop.CloseProject("wpt_m1000_verify")
    except Exception:
        pass
    log_file.close()
